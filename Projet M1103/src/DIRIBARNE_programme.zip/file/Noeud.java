package file;

public class Noeud {
    protected Object valeur;
    protected Noeud suivant;
}
